<?php
/**
 * Created by PhpStorm.
 * User: MSI
 * Date: 21/07/2015
 * Time: 4:47 CH
 */

if(!class_exists('ST_Metabox'))
{
    class ST_Metabox
    {
        function _init()
        {
            static $_metabox;
        }

        function render()
        {

        }
    }


}