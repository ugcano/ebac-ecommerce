<div id="st-admin-app"></div>
<style>
    #wpcontent{
        background:#FFF;
    }
</style>